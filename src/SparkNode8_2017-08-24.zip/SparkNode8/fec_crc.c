/*
 * fec_crc.c
 *
 * Created: 2017-08-21 09:49:21
 *  Author: etudiant
 */ 
 #include "hardware.h"
 #include "fec_crc.h"

