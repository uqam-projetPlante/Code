/*
 * Sensors.h
 *
 * Created: 2017-08-17 14:43:01
 *  Author: etudiant
 */ 


#ifndef SENSORS_H_
#define SENSORS_H_

uint8_t* Sensors_get(void);



#endif /* SENSORS_H_ */