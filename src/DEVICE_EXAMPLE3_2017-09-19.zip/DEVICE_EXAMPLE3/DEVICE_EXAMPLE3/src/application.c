/*
 * application.c
 *
 * Created: 2017-09-19 16:37:00
 *  Author: collerette_a
 */ 
#include <asf.h>
#include "conf_usb.h"
#include "ui.h"
#include "OPT3001.h"
#include "Si7021.h"
#include "MMA8491Q.h"
#include "clockout.h"
#include "spi_sercom1.h"
#include "flash.h"
#include "testbench.h"
#include "clockgen.h"
#include "i2c_driver.h"
#include "delay.h"
#include "RTC.h"
#include "LCD.h"
#include "application.h"
#include <stdio.h>
#include <math.h>

struct rtc_calendar_time mytime;
//sensor data
uint8_t* OPT3001_data;
uint8_t* Si7021_data;
uint8_t* MMA8491Q_data;
int temp1;
int RH1;
char str[];
uint8_t bright;
uint8_t contrast;

void TC3_Handler(void)
{
	temp1 =  Si7021_GetTemp();
	i2cLcdprintNum(temp1,0,26);
	RH1 = Si7021_GetRH();
	i2cLcdprintNum(RH1,0,36);
	rtc_calendar_get_time(&mytime);
	i2cLcdprintNum(mytime.hour,0,4);
	i2cLcdprintNum(mytime.minute,0,7);
	i2cLcdprintNum(mytime.second, 0, 10);
	if(mytime.pm)
	{
		str[0]='A';
		str[1]='M';
		i2cLcdPrint(0,14,str);
	}
	else
	{
		str[0]='P';
		str[1]='M';
		i2cLcdPrint(0,14,str);
	}
}

void app(){
					
}