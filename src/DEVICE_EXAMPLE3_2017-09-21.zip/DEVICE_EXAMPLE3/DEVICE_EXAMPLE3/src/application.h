/*
 * application.h
 *
 * Created: 2017-09-19 16:36:44
 *  Author: collerette_a
 */ 

#ifndef APPLICATION_H_
#define APPLICATION_H_

#define NUM_SCHEDULED_TASKS 4
	
void Schedule_config();	
void app(void);

#endif /* APPLICATION_H_ */