/*
 * flash.h
 *
 * Created: 2017-05-17 15:19:03
 *  Author: collerette_a
 */ 


#ifndef FLASH_H_
#define FLASH_H_


void configure_nvm(void);


#endif /* FLASH_H_ */