/*
 * clock.h
 *
 * Created: 2017-05-08 17:16:18
 *  Author: collerette_a
 */ 


#ifndef CLOCKOUT_H_
#define CLOCKOUT_H_



void clockout_config(void);

#endif /* MYCLOCK_H_ */