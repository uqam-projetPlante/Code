function load_toolbox
%% Script to load functions 

%% Add all toplevel functions
addpath([fileparts( mfilename('fullpath') ), '/function']);

end
