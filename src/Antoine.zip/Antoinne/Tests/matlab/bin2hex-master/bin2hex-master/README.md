
Bin2hex
=======

Example
--

    bin2hex(01011111) 
    > 5F
   
     hex2bin('5F')
    > 1011111
    
    
Installation
--

To get library clone from github:

    cd to your lib folder
    git clone https://github.com/Matlab-Toolbox/bin2hex.git

Add package to path:

    %% Add package to path
    run(['/path_to_package/bin2hex/load_toolbox.m']);
