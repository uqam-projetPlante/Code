#pragma once

void usart_init(void);
