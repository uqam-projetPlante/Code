/*
 * application.h
 *
 * Created: 2017-09-19 16:36:44
 *  Author: collerette_a
 */ 


#ifndef APPLICATION_H_
#define APPLICATION_H_

#define NUM_SCHEDULED_TASKS 2

//Must contain the same number of elements than NUM_SCHEDULED_TASKS
enum currentTask{
		TURN_LIGHT_ON		= 0x00,
		TURN_LIGHT_OFF		= 0x01,
	};

enum currentTask myTask;
struct rtc_calendar_time mySchedule[NUM_SCHEDULED_TASKS];
	
inline void Schedule_config(){
	mySchedule[TURN_LIGHT_ON].hour = 8;
	mySchedule[TURN_LIGHT_ON].minute = 0;
	mySchedule[TURN_LIGHT_ON].pm = false;

	mySchedule[TURN_LIGHT_OFF].hour = 10;
	mySchedule[TURN_LIGHT_OFF].minute = 0;
	mySchedule[TURN_LIGHT_OFF].pm = true;
}
	
void app(void);

#endif /* APPLICATION_H_ */