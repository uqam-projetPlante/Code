/*
 * application.c
 *
 * Created: 2017-09-19 16:37:00
 *  Author: collerette_a
 */ 
#include <asf.h>
#include "conf_usb.h"
#include "ui.h"
#include "OPT3001.h"
#include "Si7021.h"
#include "MMA8491Q.h"
#include "clockout.h"
#include "spi_sercom1.h"
#include "flash.h"
#include "testbench.h"
#include "clockgen.h"
#include "i2c_driver.h"
#include "delay.h"
#include "RTC.h"
#include "LCD.h"
#include "application.h"
#include "Timer1.h"
#include <stdio.h>
#include <math.h>

struct rtc_calendar_time myTime;
int temp1;
int RH1;
char str[];
bool timeset;

void TC3_Handler(void)
{
	//Print Data to LCD screen
	if(TC3->COUNT16.INTFLAG.bit.MC0)
	{
		i2cLcdprintNum(temp1,0,26);
		i2cLcdprintNum(RH1,0,36);
		rtc_calendar_get_time(&myTime);
		i2cLcdprintNum(myTime.hour,0,6);
		i2cLcdprintNum(myTime.minute,0,9);
		//i2cLcdprintNum(mytime.second, 0, 13);
		if(myTime.pm)
		{
			str[0]='A';
			str[1]='M';
			i2cLcdPrint(0,12,str);
		}
		else
		{
			str[0]='P';
			str[1]='M';
			i2cLcdPrint(0,12,str);
		}
	}
	
	// Get values from Sensors
	if(TC3->COUNT16.INTFLAG.bit.OVF)
	{
		temp1 =  Si7021_GetTemp();
		RH1 =    Si7021_GetRH();
	}
	
}

void RTC_Handler(void)
{
	switch(myTask)
	{
		case TURN_LIGHT_ON :
			//Execute task
			LED_On(LED_0_PIN);
			//Set next task
			myTask++;
			rtc_calendar_set_alarm(&(mySchedule[myTask]));
		break;
				
		case TURN_LIGHT_OFF :
			//Execute task
			LED_Off(LED_0_PIN);
			//Set next task
			myTask++;
			rtc_calendar_set_alarm(&(mySchedule[myTask]));
		break;
	}
	
	//if all task completed: go back to first task
	if (myTask == NUM_SCHEDULED_TASKS)
	{
		myTask = 0;	
		rtc_calendar_set_alarm(&(mySchedule[myTask]));
	}
	
	//clear interupt alarm0 flag
	RTC->MODE2.INTFLAG.reg = RTC_MODE2_INTFLAG_ALARM0;
}

void app(){
	while(!timeset){
		//set time
		myTime.hour      = 11;
		myTime.minute    = 0;
		myTime.pm		= true;
		rtc_calendar_set_time(&myTime);	
		
		//configure Schedule
		Schedule_config();
		
		//Find the first task to execute (next scheduled task scheduled within 1 hour of current time)
		myTask = 255;
		for(uint8_t i = (myTime.hour + 1); i <= 12; i++)
		{
			for(uint8_t j = 0; j <=(NUM_SCHEDULED_TASKS-1); j++)
			{	
				if((mySchedule[j].hour == i) && (mySchedule[j].pm == myTime.pm))
				{
					myTask = j;
				}
			}
		}	
		if(myTask == 255)
		{
			for(int i = 0; i < 12; i++)
			{
				for(uint8_t j = 0; j <=(NUM_SCHEDULED_TASKS-1); j++)
				{
					if((mySchedule[j].hour == i) && (mySchedule[j].pm != myTime.pm))
					{
						myTask = j;
					}
				}
			}
		}
					
		rtc_calendar_set_alarm(&(mySchedule[myTask]));
		
		//	start app
		timeset = true;	
	}
	
	
	
}